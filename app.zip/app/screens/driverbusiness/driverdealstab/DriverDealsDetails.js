import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  ScrollView,
  FlatList,
  Dimensions
} from 'react-native';
import { Container, Left, Body, Right, Button, Icon, Title } from 'native-base';
let deviceWidth = Dimensions.get('window').width
import { Header } from 'react-native-elements';

export default class Blog extends Component {

  constructor(props) {
    super(props);
    this.state = {
      dataSource: [
        { id: 1, flower_image_url: "https://lorempixel.com/400/200/nature/6/" },
        { id: 2, flower_image_url: "https://lorempixel.com/400/200/nature/6/" },
        { id: 3, flower_image_url: "https://lorempixel.com/400/200/nature/6/" },
        { id: 4, flower_image_url: "https://lorempixel.com/400/200/nature/6/" },
        { id: 5, flower_image_url: "https://lorempixel.com/400/200/nature/6/" },
        { id: 6, flower_image_url: "https://lorempixel.com/400/200/nature/6/" },
      ]
    };
  }

  goBack() {
    this.props.navigation.goBack();
  }

  render() {
    return (
      <ScrollView style={styles.container}>
        {/* <Header style={{ backgroundColor: "#ffffff" }}>
          <Left>
            <Button transparent onPress={this.goBack.bind(this)}>
              <Image source={require('../../../../assets/t13.png')} style={{ width: 25, height: 25 }} />
            </Button>
          </Left>
          <Body style={{ paddingLeft: 75 }}>
            <Title style={{ color: 'black' }}>Deals Details</Title>
          </Body>
        </Header> */}
        <Header
          leftComponent={<Button transparent onPress={this.goBack.bind(this)}><Image source={require('../../../../assets/images/next-arrow.png')} style={{ width: 21, height: 21, marginBottom: 25, transform: [{ rotate: '185deg' }] }} /></Button>}
          centerComponent={{ text: 'Deal Details', style: { color: '#333', marginBottom: 25, fontSize: 16 } }}
          //rightComponent={<Button transparent onPress={this.goBack.bind(this)}><Image source={require('../../../../assets/t13.png')} style={{width:25, height:25, marginBottom:25}} /></Button>}
          // rightComponent={
          //   <View style={{ flexDirection: 'row', marginBottom: 50 }}>
          //     <TouchableOpacity>
          //       <Image source={require('../../../../assets/t13.png')} style={{ width: 25, height: 25, marginBottom: 5 }} />
          //     </TouchableOpacity>
          //     <TouchableOpacity>
          //       <Image source={require('../../../../assets/t13.png')} style={{ width: 25, height: 25, marginBottom: 5 }} />
          //     </TouchableOpacity>
          //   </View>
          // }
          containerStyle={{
            backgroundColor: '#fff',
            justifyContent: 'space-around',
            height: 45,
          }}
        />
        <View style={{ marginTop: 5, borderRadius: 5, padding: 10 }}>
          <View style={{ alignContent: 'center', alignItems: 'center', alignSelf: 'center', justifyContent: 'center', borderRadius: 10 }}>
            <Image source={{ uri: 'https://image.shutterstock.com/image-photo/white-transparent-leaf-on-mirror-260nw-1029171697.jpg' }} style={{ width: deviceWidth / 1.1, height: 150, borderTopRightRadius: 10, borderTopLeftRadius: 10 }} />
          </View>
          <View style={{ padding: 16, width: deviceWidth / 1.1, alignSelf: 'center', backgroundColor: 'white', }}>
            <Text style={{ color: 'black', fontWeight: 'bold', fontSize: 17 }}>Lorem ipsum dolor</Text>
            <Text style={{ marginTop: 5, fontSize: 14 }}>Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor </Text>
          </View>
        </View>
        <View style={{ padding: 16, backgroundColor: 'white', width: deviceWidth / 1.1, alignSelf: 'center', borderRadius: 4, alignSelf: 'center' }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ color: 'black', fontWeight: 'bold', fontSize: 14 }}>Price:</Text>
            <Text style={{ fontSize: 12, color: 'red' }}>$ - 15.00</Text>
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ color: 'black', fontWeight: 'bold', fontSize: 14 }}>Buy 1 Get one Free</Text>
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ color: 'black', fontSize: 12 }}>Offer expires 01/31/2020</Text>
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ color: 'black', fontWeight: 'bold', fontSize: 12 }}>Distance:</Text>
            <Text style={{ fontSize: 12, color: 'red' }}>4.3 Miles</Text>
          </View>
          <View style={{ flexDirection: 'row', }}>
            <Text style={{ color: 'black', fontWeight: 'bold', fontSize: 12 }}>Location:</Text>
            <Text style={{ fontSize: 12, }}> Lorem ipsum is simply dummy text..</Text>
          </View>
        </View>

        <View style={{ flexDirection: 'row', justifyContent: 'space-around', marginTop: 20 }}>
          <TouchableOpacity onPress={() => this.props.navigation.navigate('ClaimRewardDriver')} style={{ flexDirection: 'row', width: 165, borderRadius: 4, backgroundColor: '#51bc12', padding: 15, alignSelf: 'center', alignContent: 'center', alignItems: 'center' }}>
            <Image source={require('../../../../assets/images/Claim-Now.png')} style={{ width: 19, height: 19 }} />
            <Text style={{ fontWeight: 'bold', fontSize: 15, marginLeft: 4, color: 'white' }}>CLAIM NOW</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{ flexDirection: 'row', width: 165, borderRadius: 4, backgroundColor: '#c2c2c2', padding: 15, alignSelf: 'center', alignContent: 'center', alignItems: 'center' }}>
            <Image source={require('../../../../assets/images/Get-Directions.png')} style={{ width: 19, height: 19 }} />
            <Text style={{ marginLeft: 4, fontSize: 15, fontWeight: 'bold' }}>GET DIRECTION</Text>
          </TouchableOpacity>
        </View>

      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  MainContainer: {

    justifyContent: 'center',
    flex: 1,
    paddingTop: (Platform.OS) === 'ios' ? 20 : 0

  },

  imageThumbnail: {
    justifyContent: 'center',
    alignItems: 'center',
    height: 150, width: 165,
    borderRadius: 8
  },

  mainImage: {

    justifyContent: 'center',
    alignItems: 'center',
    height: '100%',
    width: '98%',
    resizeMode: 'contain'

  },

  modalView: {

    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.4)'

  },

  TouchableOpacity_Style: {

    width: 25,
    height: 25,
    top: 9,
    right: 9,
    position: 'absolute'

  }

}); 