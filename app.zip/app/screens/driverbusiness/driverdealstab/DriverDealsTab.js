import React from 'react';
import { View, Image, TouchableOpacity, ScrollView, FlatList, ImageBackground, Dimensions } from 'react-native';
import styles from './styles';
import { SafeAreaView, StackActions, NavigationActions } from 'react-navigation';
import { Container, Item, Input, Icon, Button, Text, Right, Left, Body, Title } from 'native-base';
import { Rating } from 'react-native-ratings';
let deviceWidth = Dimensions.get('window').width
import { Header } from 'react-native-elements';
import { SliderBox } from "react-native-image-slider-box";
class DriverServicesList extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      dataSource: [],
      images: [
        "https://source.unsplash.com/1024x768/?nature",
        "https://source.unsplash.com/1024x768/?water",
        "https://source.unsplash.com/1024x768/?tree",
        // require('./assets/images/girl.jpg'),
      ]
    }
  }

  componentDidMount() {
    const myitems = [
      { "key": "r", "image": require("../../../../assets/sample1.jpg") },
      { "key": "b", "image": require("../../../../assets/sample1.jpg") },
      { "key": "j", "image": require("../../../../assets/sample1.jpg") },
      { "key": "h", "image": require("../../../../assets/sample1.jpg") },
      { "key": "k", "image": require("../../../../assets/sample1.jpg") },
      { "key": "c", "image": require("../../../../assets/sample1.jpg") },
      { "key": "d", "image": require("../../../../assets/sample1.jpg") },
      { "key": "e", "image": require("../../../../assets/sample1.jpg") },
      { "key": "f", "image": require("../../../../assets/sample1.jpg") }
    ];
    this.setState({ dataSource: myitems })
  }

  DriverDealsDetails() {
    this.props.navigation.navigate('DriverDealsDetails');
  }

  renderItem = data =>

    <TouchableOpacity style={[styles.card, { backgroundColor: 'white' }]} onPress={() => this.DriverDealsDetails()}>
      <View style={styles.imageContainer}>
        <Image style={styles.cardImage} source={require('../../../../assets/sample1.jpg')} />
      </View>
      <View style={[styles.cardContent, { padding: 10, borderBottomRightRadius: 10, borderBottomLeftRadius: 10 }]}>
        <View style={{ flexDirection: 'row', }}>
          <Text style={[styles.title, { color: 'black', fontSize: 13, fontWeight: 'bold' }]}>Oil Change</Text>
        </View>
        <Text style={{ fontSize: 11 }}>Lorem ipsum is dummy.</Text>
        <Text style={styles.count}>Buy 1 get One free</Text>
      </View>
    </TouchableOpacity>

  goBack() {
    this.props.navigation.goBack();
  }



  render() {

    return (
      <View style={styles.wrapper}>
        <Header
          leftComponent={<Button transparent onPress={this.goBack.bind(this)}><Image source={require('../../../../assets/images/next-arrow.png')} style={{ width: 18, height: 21, marginBottom: 25, transform: [{ rotate: '185deg' }] }} /></Button>}
          centerComponent={{ text: 'Deals', style: { color: '#333', marginBottom: 25, fontSize: 16 } }}
          rightComponent={
            <View style={{ flexDirection: 'row',}}>
                <TouchableOpacity style={{marginBottom:20 }}>
                    <Image source={require('../../../../assets/images/white-inbox.png')} style={{ width: 18, height: 18, marginBottom: 1 }} />
                </TouchableOpacity>
                <TouchableOpacity>
                    <Image source={require('../../../../assets/images/filter.png')} style={{ width: 18, height: 18, marginBottom: 2 }} />
                </TouchableOpacity>
            </View>
        }
          containerStyle={{
            backgroundColor: '#fff',
            justifyContent: 'space-around',
            height: 45,
          }}
        />
        {this.state.loading ?
          <ActivityIndicator
            animating={this.state.loading}
            color='#FF0000'
            size="large"
            style={styles.activityIndicator} />
          :
          <ScrollView>
            <View style={{ flex: 1, marginTop: 15 }}>
              <SliderBox
                images={this.state.images}
                onCurrentImagePressed={index =>
                  console.warn(`image ${index} pressed`)
                }
                ImageComponentStyle={{ borderRadius: 5, width: '88%' }}
              />
              <Text style={{ alignSelf: 'flex-end', paddingRight: 30, fontSize:14 }}>E-Advertisement</Text>
            </View>
            <View style={{ marginTop: 30 }}>
              <FlatList
                numColumns={2}
                data={this.state.dataSource}
                contentContainerStyle={styles.container}
                renderItem={item => this.renderItem(item)}
                // keyExtractor={item => item.id.toString()}
                extraData={this.state}
                columnWrapperStyle={styles.row} />
            </View>
          </ScrollView>}

      </View>
    )
  }

}

export default DriverServicesList;