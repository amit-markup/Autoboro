import React from 'react';
import { View, Image, Text, ActivityIndicator, FlatList, TouchableOpacity, ScrollView } from 'react-native';
import styles from './styles';
import { SafeAreaView, StackActions, NavigationActions } from 'react-navigation';
import Constants from '../../../config/constant'
import Toast, { DURATION } from 'react-native-easy-toast';
import { Container, Left, Body, Right, Button, Title, Item, Input } from 'native-base';
import LinearGradient from 'react-native-linear-gradient';
import AsyncStorage from '@react-native-community/async-storage';
import { Header, Icon, Avatar } from 'react-native-elements';

class DriverProfileTab extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            profileImage: '',
            loading: true,
            carType: '',
            carModel: '',
            firstName: '',
            lastName: '',
        }
        this.getProfileData();
    }

    async getProfileData() {
        try {
            // let authToken = '';
            // AsyncStorage.getItem('driverToken').then((driverToken) => {
            //     if(driverToken){
            //         authToken = driverToken;
            //         console.log("tokenis***1***" + authToken);
            //     }
            // });
            // AsyncStorage.getItem('businessToken').then((businessToken) => {
            //     if(businessToken){
            //         authToken = businessToken;
            //         console.log("tokenis***2***" + authToken);
            //     }
            // });
            var profile = JSON.parse(await AsyncStorage.getItem("profile"));
            //console.log('profile', profile)
            let authToken = profile.token;
            //console.log('profile', authToken)
            let response = await fetch(
                Constants.BASE_URL + 'auth/profile', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + authToken,
                    'X-Requested-With': 'XMLHttpRequest',
                },
            });
            this.setState({ loading: false })
            let responseJson = await response.json();
            console.log('fdjsioadjfuisdgj', responseJson)
            this.success(responseJson);
            return responseJson;
        } catch (error) {
            console.error(error);
            this.setState({ loading: false })
        }
    }

    async success(profiless) {
        console.log('profile', profiless)
        var image = profiles.avatar
        console.log('image', image)
        await AsyncStorage.setItem("profiles", JSON.stringify(profiless));
        let carType = profiles.car_info
        this.setState({
            firstName: profiless.first_name,
            lastName: profiless.last_name,
            profileImage: profiless.avatar,
            carType: carType.item.car_brand,
            carType: carType.item.car_type,
        })
    }


    goBack() {
        this.props.navigation.navigate('DriverHomeTab');
    }

    render() {

        let splashImg = require("../../../../assets/splash_bg.png");

        let car = require("../../../../assets/car.png");
        let back = require('../../../../assets/images/next-arrow.png');
        let model = require("../../../../assets/model.png");
        let years = require("../../../../assets/years.png");
        let vin = require("../../../../assets/vin-no.png");
        let register = require("../../../../assets/register-no.png");
        let calender = require("../../../../assets/years.png");

        return (
            <SafeAreaView style={styles.wrapper}>
                {/* <Text style={{ height: 30, alignSelf: 'flex-start', marginLeft: '5%', marginRight: '5%', color: '#000000', marginTop: 10 }}>Profile Tab</Text> */}

                <Header
                    leftComponent={<Button transparent onPress={this.goBack.bind(this)}><Image source={require('../../../../assets/images/back-arrow.png')} style={{ width: 21, height: 21, marginBottom: 25 }} /></Button>}
                    centerComponent={{ text: 'My Profile', style: { color: '#fff', marginBottom: 25, fontSize: 16 } }}
                    //rightComponent={<Button transparent onPress={this.goBack.bind(this)}><Image source={require('../../../../assets/t13.png')} style={{width:25, height:25, marginBottom:25}} /></Button>}
                    rightComponent={
                        <View style={{ flexDirection: 'row',}}>
                            <TouchableOpacity style={{marginBottom:20 }}  onPress={()=> this.props.navigation.navigate('DriverInbox')}>
                                <Image source={require('../../../../assets/images/white-inbox.png')} style={{ width: 25, height: 25, marginBottom: 5 }} />
                            </TouchableOpacity>
                            <TouchableOpacity onPress={()=> this.props.navigation.navigate('VehicleDriverSetting')}>
                                <Image source={require('../../../../assets/images/white-setting.png')} style={{ width: 25, height: 25, marginBottom: 5 }} />
                            </TouchableOpacity>
                        </View>
                    }
                    containerStyle={{
                        backgroundColor: '#d55459',
                        justifyContent: 'space-around',
                        height: 45,
                    }}
                />

                <ScrollView contentContainerStyle={{ minHeight: '100%' }}>

                    {this.state.loading ?
                        <ActivityIndicator
                            animating={this.state.loading}
                            color='#FF0000'
                            size="large"
                            style={styles.activityIndicator} />
                        :
                        <View>
                            <LinearGradient colors={['#d55459', '#a32227', '#96151a']} style={{ height: 180, width: '100%' }}>
                                <View>
                                    {/* <Image source={this.state.profileImage != '' ? { uri: this.state.profileImage } : splashImg} style={{ width: 120, height: 120, borderRadius: 120 / 2, alignSelf: 'center', marginTop: 10 }}></Image>
                                    <TouchableOpacity style={{ height: 35, backgroundColor: 'black', borderRadius: 30, width: 35, position: 'absolute', padding: 5, marginTop: 100, marginLeft: 227 }}>
                                        {/* <Image source={splashImg} style={{ height: 30, width: 30, borderRadius:30 }}></Image> */}
                                        {/* <Icon name='edit' size={25} type='FontAwesome' color='white' />
                                    </TouchableOpacity> */} 
                                    <Avatar
                                        size={110}
                                        //onPress={this.takePicture.bind(this)}
                                        // onPress={() => this.goToEditBusinessProfile()}
                                        overlayContainerStyle={{ backgroundColor: '#FFF' }}
                                        rounded
                                        icon={{ name: 'plus', type: 'font-awesome', color: 'gray', size: 20 }}
                                        containerStyle={{ borderColor: 'gray', borderWidth: 0, alignSelf: 'center', marginTop:10 }}
                                        source={splashImg}
                                        imageProps={{ resizeMode: 'cover' }}
                                        showEditButton
                                    />
                                    <Text style={{ color: '#FFFFFF', alignSelf: 'center', fontFamily: 'Roboto_Regular', marginTop: 10 }}>{this.state.firstName}{this.state.lastName}</Text>
                                </View>
                            </LinearGradient>

                            {/* <Item regular style={styles.viewLabel1}>
              <Input style={styles.input} placeholder='Email' onChangeText={(text) => this.setState({ email: text })}/>
            </Item> */}
                            <View style={styles.viewLabel1}>
                                <Image style={{ width: 22, height: 18, marginLeft: 10, alignSelf: 'center' }} source={car}></Image>
                                <Text style={{ color: '#000000', marginLeft: 10, alignSelf: 'center', flex: 2 }}>{this.state.carType}</Text>
                                <Image style={{ width: 20, height: 20, alignSelf: 'center', marginRight: 10, flex: 0.08 }} source={back}></Image>
                            </View>
                            <View style={styles.viewLabel1}>
                                <Image style={{ width: 22, height: 18, marginLeft: 10, alignSelf: 'center' }} source={model}></Image>
                                <Text style={{ color: '#000000', marginLeft: 10, alignSelf: 'center', flex: 2 }}>{this.state.carModel}</Text>
                                <Image style={{ width: 20, height: 20, alignSelf: 'center', marginRight: 10, flex: 0.08 }} source={back}></Image>
                            </View>
                            <View style={styles.viewLabel1}>
                                <Image style={{ width: 22, height: 18, marginLeft: 10, alignSelf: 'center' }} source={years}></Image>
                                <Text style={{ color: '#000000', marginLeft: 10, alignSelf: 'center', flex: 2 }}>Manufacturing</Text>
                                <Image style={{ width: 20, height: 20, alignSelf: 'center', marginRight: 10, flex: 0.08 }} source={back}></Image>
                            </View>
                            <View style={styles.viewLabel1}>
                                <Image style={{ width: 22, height: 18, marginLeft: 10, alignSelf: 'center' }} source={vin}></Image>
                                <Text style={{ color: '#000000', marginLeft: 10, alignSelf: 'center', flex: 2 }}>Odometer Reading</Text>
                                <Image style={{ width: 20, height: 20, alignSelf: 'center', marginRight: 10, flex: 0.08 }} source={back}></Image>
                            </View>
                            <View style={styles.viewLabel1}>
                                <Image style={{ width: 22, height: 18, marginLeft: 10, alignSelf: 'center', }} source={register}></Image>
                                <Text style={{ color: '#000000', marginLeft: 10, alignSelf: 'center', flex: 2 }}>Insurance Provider</Text>
                                <Image style={{ width: 20, height: 20, alignSelf: 'center', marginRight: 10, flex: 0.08 }} source={back}></Image>
                            </View>
                            <View style={styles.viewLabel1}>
                                <Image style={{ width: 22, height: 18, marginLeft: 10, alignSelf: 'center', }} source={register}></Image>
                                <Text style={{ color: '#000000', marginLeft: 10, alignSelf: 'center', flex: 2 }}>Insurance Policy Number</Text>
                                <Image style={{ width: 20, height: 20, alignSelf: 'center', marginRight: 10, flex: 0.08 }} source={back}></Image>
                            </View>
                            <View style={styles.viewLabel1}>
                                <Image style={{ width: 22, height: 18, marginLeft: 10, alignSelf: 'center' }} source={register}></Image>
                                <Text style={{ color: '#000000', marginLeft: 10, alignSelf: 'center', flex: 2 }}>License Number</Text>
                                <Image style={{ width: 20, height: 20, alignSelf: 'center', marginRight: 10, flex: 0.08 }} source={back}></Image>
                            </View>
                            <View style={styles.viewLabel1}>
                                <Image style={{ width: 22, height: 18, marginLeft: 10, alignSelf: 'center' }} source={calender}></Image>
                                <Text style={{ color: '#000000', marginLeft: 10, alignSelf: 'center', flex: 2 }}>Expiration Date</Text>
                                <Image style={{ width: 20, height: 20, alignSelf: 'center', marginRight: 10, flex: 0.08 }} source={back}></Image>
                            </View>
                            <Button block style={{ width: '90%', marginLeft: '5%', marginRight: '5%', marginTop: 15, backgroundColor: '#de1f27' }} onPress={() => this.props.navigation.navigate('VehicleDriverSetting')}>
                                <Text style={{ color: '#FFFFFF', fontFamily: 'Roboto_Bold' }}>VEHICLE SETTINGS</Text>
                            </Button>
                            <View style={{ height: 75, width: '100%' }}></View>
                            <TouchableOpacity onPress={() => this.props.navigation.navigate('Logout')} style={{ alignSelf: 'center', padding: 15, backgroundColor: 'green', marginBottom: 20 }}>
                                <Text>LogOut</Text>
                            </TouchableOpacity>

                        </View>}
                </ScrollView>
            </SafeAreaView>
        )
    }

}

export default DriverProfileTab;