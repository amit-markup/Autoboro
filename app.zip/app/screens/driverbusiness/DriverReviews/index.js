import React, { Component } from 'react';
import {
    StyleSheet,
    Text,
    View,
    Alert,
    TouchableOpacity,
    FlatList,
    Image
} from 'react-native';
import { Rating } from 'react-native-ratings';
import { Header, Left, Body, Button, Title } from 'native-base';

export default class EventsView extends Component {

    constructor(props) {
        super(props);
        this.state = {
            dataSource: [
                { day: 1, month: 'Sep' },
                { day: 2, month: 'Jan' },
                { day: 3, month: 'Aug' },
                { day: 4, month: 'Dec' },
                { day: 5, month: 'Jul' },
                { day: 6, month: 'Oct' },
                { day: 7, month: 'Sep' },
                { day: 8, month: 'Jan' },
                { day: 9, month: 'May' },
            ],
            value: 0
        };
    }

    eventClickListener = (viewId) => {
        Alert.alert("alert", "event clicked");
    }

    goBack() {
        this.props.navigation.goBack();
    }

    render() {
        return (
            <View style={styles.container}>
                <Header style={{ backgroundColor: "#ffffff", marginBottom:30 }}>
                    <Left>
                        <Button transparent onPress={this.goBack.bind(this)}>
                            {/* <Icon name='arrow-back'/> */}
                            <Image source={require('../../../../assets/images/next-arrow.png')} style={{ width: 21, height: 21, transform: [{ rotate: '185deg' }] }} />
                        </Button>
                    </Left>
                    <Body style={{ paddingLeft: 20 }}>
                        <Title style={{ color: 'black', fontSize:16 }}>Services Details</Title>
                    </Body>
                </Header>
                <Text style={{ paddingLeft: 10 }}>Reviews</Text>
                <FlatList enableEmptySections={true}
                    style={styles.eventList}
                    data={this.state.dataSource}
                    extraData={this.state}
                    keyExtractor={(item) => {
                        return item.id;
                    }}
                    renderItem={(item) => {
                        return (
                            <TouchableOpacity onPress={() => this.eventClickListener("row")}>
                                <View style={styles.eventBox}>
                                    <View style={styles.eventDate}>
                                        <Image source={{ uri: 'https://bootdey.com/img/Content/avatar/avatar1.png' }} style={[styles.eventDay, { alignSelf: 'center', alignContent: 'center', alignItems: 'center' }]} />
                                        <Text style={[styles.eventMonth, { alignSelf: 'center', alignContent: 'center', alignItems: 'center' }]}>2</Text>
                                        <Text style={styles.eventMonth}>Reviews</Text>
                                    </View>
                                    <View style={styles.eventContent}>
                                        <View style={{ flexDirection: 'row' }}>
                                            <Text style={styles.userName}>Richard Grant</Text>
                                            <View style={{ paddingLeft: 90, paddingTop: 4 }}>
                                                <Rating
                                                    type='star'
                                                    ratingCount={5}
                                                    imageSize={10}
                                                    startingValue={3}
                                                />
                                            </View>
                                        </View>
                                        <Text style={styles.description}>Lorem ipsum dolor sit amet, elit consectetur</Text>
                                    </View>
                                </View>
                            </TouchableOpacity>
                        )
                    }} />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#DCDCDC",
        flex: 1,
    },
    eventList: {
        marginTop: 0,
    },
    eventBox: {
        padding: 10,
        marginTop: 5,
        marginBottom: 5,
        flexDirection: 'row',
    },
    eventDate: {
        flexDirection: 'column',
    },
    eventDay: {
        width: 35,
        height: 35,
        borderRadius: 30
    },
    eventMonth: {
        fontSize: 14,
        color: "#333",
        fontWeight: "600",
    },
    eventContent: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'flex-start',
        marginLeft: 10,
        backgroundColor: '#FFFFFF',
        padding: 10,
        borderRadius: 10
    },
    description: {
        fontSize: 15,
        color: "#646464",
    },
    eventTime: {
        fontSize: 18,
        color: "#151515",
    },
    userName: {
        fontSize: 16,
        color: "#151515",
    },
});