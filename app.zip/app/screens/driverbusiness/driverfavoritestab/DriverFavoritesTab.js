import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  ScrollView,
  FlatList,
} from 'react-native';
import { Container,  Left, Body, Right, Button, Icon, Title } from 'native-base';
import { Header } from 'react-native-elements';

export default class Album extends Component {

  constructor(props) {
    super(props);
    this.state = {
      data: [
        { id: 1, title: "2D%", title2: " off today!", count: 'Te legions 100/2020', image: "https://bootdey.com/img/Content/avatar/avatar6.png" },
        { id: 2, title: "2D%", title2: " off today!", count: 'Te legions 100/2020', image: "https://bootdey.com/img/Content/avatar/avatar6.png" },
        { id: 3, title: "2D%", title2: " off today!", count: 'Te legions 100/2020', image: "https://bootdey.com/img/Content/avatar/avatar6.png" },
        { id: 4, title: "2D%", title2: " off today!", count: 'Te legions 100/2020', image: "https://bootdey.com/img/Content/avatar/avatar6.png" },
        { id: 5, title: "2D%", title2: " off today!", count: 'Te legions 100/2020', image: "https://bootdey.com/img/Content/avatar/avatar6.png" },
        { id: 6, title: "2D%", title2: " off today!", count: 'Te legions 100/2020', image: "https://bootdey.com/img/Content/avatar/avatar6.png" },
        { id: 7, title: "2D%", title2: " off today!", count: 'Te legions 100/2020', image: "https://bootdey.com/img/Content/avatar/avatar6.png" },
        { id: 8, title: "2D%", title2: " off today!", count: 'Te legions 100/2020', image: "https://bootdey.com/img/Content/avatar/avatar6.png" },
        { id: 9, title: "2D%", title2: " off today!", count: 'Te legions 100/2020', image: "https://bootdey.com/img/Content/avatar/avatar6.png" },
        { id: 9, title: "2D%", title2: " off today!", count: 'Te legions 100/2020', image: "https://bootdey.com/img/Content/avatar/avatar6.png" },
      ]
    };
  }

  gallaryDetails = () => {
    this.props.navigation.navigate('DriverServiceGalleryDetails')
  }

  goBack() {
    this.props.navigation.goBack();
  }

  render() {
    return (
      <View style={styles.container}>
        <Header
          leftComponent={<Button transparent onPress={this.goBack.bind(this)}><Image source={require('../../../../assets/images/next-arrow.png')} style={{ width: 18, height: 21, marginBottom: 25, transform: [{ rotate: '185deg' }] }} /></Button>}
          centerComponent={{ text: 'Favorites', style: { color: '#333', marginBottom: 25, fontSize: 16 } }}
          rightComponent={
            <View style={{ flexDirection: 'row',}}>
                <TouchableOpacity style={{marginBottom:20 }}>
                    <Image source={require('../../../../assets/images/white-inbox.png')} style={{ width: 18, height: 18, marginBottom: 1 }} />
                </TouchableOpacity>
                <TouchableOpacity>
                    <Image source={require('../../../../assets/images/filter.png')} style={{ width: 18, height: 18, marginBottom: 2 }} />
                </TouchableOpacity>
            </View>
        }
          containerStyle={{
            backgroundColor: '#fff',
            justifyContent: 'space-around',
            height: 45,
          }}
        />
        <FlatList style={styles.list}
          contentContainerStyle={styles.listContainer}
          data={this.state.data}
          horizontal={false}
          numColumns={2}
          keyExtractor={(item) => {
            return item.id;
          }}
          ItemSeparatorComponent={() => {
            return (
              <View style={styles.separator} />
            )
          }}
          renderItem={() => {
            return (
              <TouchableOpacity style={styles.card}>
                <View style={styles.imageContainer}>
                  <Image style={styles.cardImage} source={require('../../../../assets/sample1.jpg')} />
                </View>
                <View style={styles.cardContent}>
                  <Text style={{fontSize:12, fontWeight:'bold'}}>Brackes</Text>
                  <Text style={{fontSize:11}}>Lorem ipsum is dummy content..</Text>
                  <View style={{ flexDirection: 'row' }}>
                    <Text style={[styles.title, {fontSize:12}]}>Price: </Text>
                    <Text style={[styles.title, { color: 'red',fontSize:12 }]}>$12.00</Text>
                  </View>
                </View>
              </TouchableOpacity>
            )
          }} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 0,
    backgroundColor: '#f1f1f1'
  },
  list: {
    paddingHorizontal: 10,
  },
  listContainer: {
    alignItems: 'center'
  },
  separator: {
    marginTop: 10,
  },
  /******** card **************/
  card: {
    marginVertical: 8,
    //backgroundColor:"white",
    flexBasis: '45%',
    marginHorizontal: 10,
  },
  cardContent: {
    paddingVertical: 8,
    justifyContent: 'space-between',
  },
  cardImage: {
    flex: 1,
    height: 150,
    width: null,
  },
  imageContainer: {
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.32,
    shadowRadius: 5.46,

    elevation: 9,
  },
  /******** card components **************/
  title: {
    fontSize: 15,
    fontWeight: 'bold',
    color: "black"
  },
  count: {
    fontSize: 14,
    color: "black"
  },
}); 