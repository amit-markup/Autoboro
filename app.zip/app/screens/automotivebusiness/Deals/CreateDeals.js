import React from 'react';
import { View, Image, FlatList, Text, ScrollView, TouchableOpacity, Modal, Dimensions, ActivityIndicator, Picker } from 'react-native';
import styles from '../../automotivebusiness/Registration2/styles';
import { SafeAreaView, StackActions, NavigationActions } from 'react-navigation';
import ImagePicker from 'react-native-image-picker';
import { Container, Textarea, Content, Form, Item, Input, Label, Button, Left, Body, Right, Title, Icon } from 'native-base';
import LinearGradient from 'react-native-linear-gradient';
import Toast, { DURATION } from 'react-native-easy-toast';
import Constants from '../../../config/constant'
import { Header } from 'react-native-elements';

class Registration2 extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      avatarSource: '',
      language: '',
      dataSource: [],
      languageList: [],
    }

    this.getLanguageApi();
  }



  takePicture(strType) {
    let that = this;
    const options = {
      title: 'Select Avatar',
      storageOptions: {
        skipBackup: true,
        path: 'images',
      },
    };

    ImagePicker.showImagePicker(options, (response) => {
      console.log('Response = ', response);

      if (response.didCancel) {
        console.log('User cancelled image picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      } else {
        // const source = { uri: response.uri };
        const source = response.uri;

        // You can also display the image using data:
        // const source = { uri: 'data:image/jpeg;base64,' + response.data };
        console.log("imageis******", source);


        if (strType == 'businessImage') {
          this.setState({ businessImage: source });

        }
        else if (strType == 'businessLogo') {
          this.setState({ avatarSource: source }, () => {
            that.joinData();
          });
        }
        else if (strType == 'managerImage') {
          this.setState({ managerImage: source });
        }

      }
    });
  }


  async getLanguageApi() {
    let that = this;
    try {
      let response = await fetch(
        Constants.BASE_URL + 'languages', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      // this.setState({ loading: false })
      let responseJson = await response.json();
      console.log("responseis*****" + JSON.stringify(responseJson) + "******" + response.status);
      if (response.status == 200) {
        this.setState({ languageList: responseJson['data'] })
      }
      // this.setLanguagePicker(response.status, responseJson);
      return responseJson;
    } catch (error) {
      console.error(error);
      this.setState({ loading: false })
    }
  }



  goBack() {
    this.props.navigation.navigate('Deals');
  }
  CreateDeals() {
    this.props.navigation.navigate('CreateAudiance');
  }


  render() {

    let splashImg = require("../../../../assets/splash_bg.png");
    let splashImgs = require("../../../../assets/images/upload-image.png");
    let popup = require("../../../../assets/cross-popup.png");
    let congratulations = require("../../../../assets/congratulations.png");
    let dob = require("../../../../assets/dob-icon.png");
    let splash = require("../../../../assets/camera.png");
    let datePickerHolder = null
    let registrationDoneHolder = null

    let languageList = this.state.languageList.map((list, index) => {
      return (
        <Picker.Item label={list.title} value={list.id} key={index} style={{ fontFamily: 'Roboto_Regular' }} />
      );
    });
    let logoImg = require("../../../../assets/4.png");

    return (
      <SafeAreaView style={styles.wrapper}>
        <Header
          leftComponent={<Button transparent onPress={this.goBack.bind(this)}><Image source={require('../../../../assets/images/back-arrow.png')} style={{ width: 25, height: 25, marginBottom: 25 }} /></Button>}
          centerComponent={{ text: 'Create Deals', style: { color: '#fff', marginBottom: 25, fontSize: 16 } }}
          //rightComponent={{ icon: 'home', color: '#fff' }}
          containerStyle={{
            backgroundColor: '#d55459',
            justifyContent: 'space-around',
            height: 45,
          }}
        />
        <ScrollView contentContainerStyle={{ minHeight: '100%' }}>
          <View>
            {/* <Header style={{ backgroundColor: '#d55459' }}>
                <Left>
                  <Button transparent onPress={this.goBack.bind(this)}>
                    <Icon name='arrow-back' />
                  </Button>
                </Left>
                <Body style={{paddingLeft:40}}>
                  <Title style={{fontFamily: 'Roboto_Regular'}}>Create Deals</Title>
                </Body>
              </Header> */}
            <LinearGradient colors={['#d55459', '#a32227', '#96151a']} style={{ height: 270, width: '100%', backgroundColor: '#FF0000' }}>
              <View >
                <Image source={splashImg} style={{ height: 180, width: '80%', alignSelf: 'center', marginTop: 30, marginBottom: 30 }}></Image>
                <TouchableOpacity style={{ height: 30, width: 30, position: 'absolute', alignSelf: 'center', marginTop: 195 }} onPress={this.takePicture.bind(this, 'businessImage')}>
                  <Image source={splashImgs} style={{ height: 30, width: 30, borderRadius: 30 }}></Image>
                </TouchableOpacity>
                <Text style={{ color: '#FFFFFF', alignSelf: 'center', fontFamily: 'Roboto_Regular' }}>Upload Deal Picture</Text>
              </View>
            </LinearGradient>

            <View style={{ width: "90%", borderWidth: 1, marginLeft: 20, marginTop: 20 }}>
              <Textarea placeholder="Please Specify the deal" rowSpan={5} bordered ref={bio => { this.bio = bio }} onChangeText={(text) => this.setState({ 'bio': text })} style={{ backgroundColor: '#f3f3f3', borderColor: '#e8e8e8', height: 80 }} />
            </View>
            <View style={{ width: '90%', marginLeft: '5%', backgroundColor: 'white', marginRight: '5%', marginTop: 10, borderColor: '#000000', borderRadius: 1, borderWidth: 1, }}>
              <Picker
                selectedValue={this.state.language}
                style={{ height: 45, width: '100%' }}
                onValueChange={(itemValue, itemIndex) =>
                  this.setState({ language: itemValue })
                }>
                {/* <Picker.Item label="Java" value="java" />
                        <Picker.Item label="JavaScript" value="js" /> */}
                <Picker.Item value='' label='Select Language' style={{ fontFamily: 'Roboto_Regular' }} />
                {languageList}
              </Picker>
            </View>
            <Item regular style={[styles.viewLabel1, { marginTop: 20 }]}>
              <Input style={styles.input} placeholder='Preset' onChangeText={(text) => this.setState({ location: text })} />
            </Item>
            <Item regular style={[styles.viewLabel1, { marginTop: 20 }]}>
              <Input style={styles.input} placeholder='Create an audiance' onChangeText={(text) => this.setState({ description: text })} />
            </Item>

            <Button block style={{ width: '90%', borderRadius: 10, marginLeft: '5%', marginRight: '5%', marginTop: 30, marginBottom: 50, backgroundColor: '#bd3c41' }} onPress={() => this.CreateDeals()}>
              {this.state.loadingRegister ?

                <ActivityIndicator
                  animating={this.state.loadingRegister}
                  color='#FFFFFF'
                  size="large"
                  style={styles.activityIndicator} />
                :

                <Text style={{ color: '#FFFFFF', }}>Submit</Text>}
            </Button>

            {datePickerHolder}
            {registrationDoneHolder}

          </View>

        </ScrollView>

        <Toast ref="toast" />

      </SafeAreaView>
    )
  }

}

export default Registration2;