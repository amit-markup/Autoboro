import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
  ScrollView,
  FlatList,
  TouchableWithoutFeedback
} from 'react-native';
import { Header, Left, Body, Item, Right, Button, Input, Icon, Title } from 'native-base';

export default class Posts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [
        { id: 1, title: "Lorem ipsum dolor", time: "1 days a go", },
        { id: 2, title: "Sit amet, consectetuer", time: "2 minutes a go", },
        { id: 3, title: "Dipiscing elit. Aenean ", time: "3 hour a go", },
        { id: 4, title: "Commodo ligula eget dolor.", time: "4 months a go", },
        { id: 5, title: "Aenean massa. Cum sociis", time: "5 weeks a go", },
        { id: 6, title: "Natoque penatibus et magnis", time: "6 year a go", },
        { id: 7, title: "Dis parturient montes, nascetur", time: "7 minutes a go", },
        { id: 8, title: "Ridiculus mus. Donec quam", time: "8 days a go", },
        { id: 9, title: "Felis, ultricies nec, pellentesque", time: "9 minutes a go", },
      ]
    };
  }

  render() {
    return (
      <View style={styles.container}>
        <Header style={{ backgroundColor: "#ffffff", marginBottom: 0 }}>
          <Left>
            <Button transparent>
              <Image source={require('../../../../assets/images/next-arrow.png')} style={{ width: 21, height: 21, transform: [{ rotate: '185deg' }] }} />
            </Button>
          </Left>
          <Body style={{ alignItems: 'center', paddingLeft:70 }}>
            <Title style={{ color: 'black', fontSize: 16 }}>Megazine</Title>
          </Body>
          <Right>
            <TouchableOpacity style={{paddingRight:10}}>
              <Image source={require('../../../../assets/images/Safety-and-Emissions.png')} style={{ width: 21, height: 21, }} />
            </TouchableOpacity>
            <TouchableOpacity>
              <Image source={require('../../../../assets/images/bussiness-setting.png')} style={{ width: 21, height: 21, }} />
            </TouchableOpacity>
          </Right>
        </Header>
        <View style={{ flexDirection: 'row', justifyContent: 'space-evenly', width: '100%', backgroundColor: "#E6E6E6",padding:5 }}>
          <TouchableOpacity style={{ backgroundColor: '#978307', borderRadius: 8, width: "16%", height: 60, alignItems: 'center', justifyContent: 'center' }}>
            <Image source={require('../../../../assets/images/autogram.png')} style={{ width: 25, height: 25 }} />
            <Text style={{ fontSize: 9, color: '#fff'}}>Autobiog-</Text>
            <Text style={{ fontSize: 9, color: '#fff'}}>raphy</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{ backgroundColor: '#699607', borderRadius: 8, width: "16%", height: 60, alignItems: 'center', justifyContent: 'center' }}>
            <Image source={require('../../../../assets/images/articles.png')} style={{ width: 25, height: 25 }} />
            <Text style={{ fontSize: 9, color: '#fff' }}>Article</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{ backgroundColor: '#07966a', borderRadius: 8, width: "16%", height: 60, alignItems: 'center', justifyContent: 'center' }}>
            <Image source={require('../../../../assets/images/podcasts.png')} style={{ width: 25, height: 25 }} />
            <Text style={{ fontSize: 9, color: '#fff' }}>Podcast</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{ backgroundColor: '#077e96', borderRadius: 8, width: "16%", height: 60, alignItems: 'center', justifyContent: 'center' }}>
            <Image source={require('../../../../assets/images/news.png')} style={{ width: 25, height: 25 }} />
            <Text style={{ fontSize: 9, color: '#fff' }}>News</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{ backgroundColor: '#4a0795', borderRadius: 8, width: "16%", height: 60, alignItems: 'center', justifyContent: 'center' }}>
            <Image source={require('../../../../assets/images/hiring.png')} style={{ width: 25, height: 25 }} />
            <Text style={{ fontSize: 9, color: '#fff' }}>Hiring</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{ backgroundColor: '#960770', borderRadius: 8, width: "16%", height: 60, alignItems: 'center', justifyContent: 'center' }}>
            <Image source={require('../../../../assets/images/B2B.png')} style={{ width: 25, height: 25 }} />
            <Text style={{ fontSize: 9, color: '#fff' }}>B2B</Text>
          </TouchableOpacity>
        </View>
        <Header style={{ backgroundColor: "#E6E6E6", marginLeft: 0 }} searchBar rounded noLeft noShadow>
          <Item>
            <Input placeholder="Search" />
            <Icon name="ios-search" />
          </Item>
          <Right style={{  maxWidth: 45, marginLeft: 10, justifyContent: 'center', marginRight: 5 }}>
            <TouchableWithoutFeedback style={{  margin: 5 }}>
              {/* <Icon name="ios-funnel" style={{ fontSize: 25, padding: 6, color: 'white', backgroundColor: '#383232' }} /> */}
              <Image source={require('../../../../assets/images/black-menu.png')} style={{ width: 38, height: 38 }} />
            </TouchableWithoutFeedback>
          </Right>
        </Header>
        <FlatList style={styles.list}
          data={this.state.data}
          keyExtractor={(item) => {
            return item.id;
          }}
          ItemSeparatorComponent={() => {
            return (
              <View style={styles.separator} />
            )
          }}
          renderItem={(post) => {
            const item = post.item;
            return (
              <View style={styles.card}>
                <Image style={styles.cardImage} source={require('../../../../assets/sample1.jpg')} />
                <View style={styles.cardFooter}>
                  <View>
                    <Image source={{ uri: 'https://bootdey.com/img/Content/avatar/avatar6.png' }} style={{ width: 40, height: 40, borderRadius: 30 }} />
                  </View>
                  <View style={{ marginLeft: 2, marginTop: 5 }}>
                    <Text style={{ fontSize: 12, fontWeight: 'bold' }}>Fast Food Restaurants</Text>
                    <Text style={{ fontSize: 12 }}>Lorem ipsum is dummy content..</Text>
                  </View>
                  <View style={{ flexDirection: 'row', paddingTop: 10 }}>
                    <Image source={require('../../../../assets/images/like.png')} style={{ width: 25, height: 25 }} />
                    <Image source={require('../../../../assets/images/dislike.png')} style={{ width: 25, height: 25, marginLeft: 3 }} />
                  </View>
                </View>
              </View>
            )
          }} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  list: {
    paddingHorizontal: 17,
    backgroundColor: "#E6E6E6",
  },
  separator: {
    marginTop: 10,
  },
  /******** card **************/
  card: {
    shadowColor: '#00000021',
    shadowOffset: {
      width: 2
    },
    shadowOpacity: 0.5,
    shadowRadius: 4,
    marginVertical: 8,
    backgroundColor: "white",
  },
  cardHeader: {
    paddingVertical: 17,
    paddingHorizontal: 16,
    borderTopLeftRadius: 1,
    borderTopRightRadius: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  cardContent: {
    paddingVertical: 12.5,
    paddingHorizontal: 16,
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingTop: 12.5,
    paddingBottom: 25,
    paddingHorizontal: 16,
    borderBottomLeftRadius: 1,
    borderBottomRightRadius: 1,
  },
  cardImage: {
    flex: 1,
    height: 150,
    width: null,
  },
  /******** card components **************/
  title: {
    fontSize: 18,
    flex: 1,
  },
  time: {
    fontSize: 13,
    color: "#808080",
    marginTop: 5
  },
  icon: {
    width: 25,
    height: 25,
  },
  /******** social bar ******************/
  socialBarContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    flex: 1
  },
  socialBarSection: {
    justifyContent: 'center',
    flexDirection: 'row',
    flex: 1,
  },
  socialBarlabel: {
    marginLeft: 8,
    alignSelf: 'flex-end',
    justifyContent: 'center',
  },
  socialBarButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  }
}); 