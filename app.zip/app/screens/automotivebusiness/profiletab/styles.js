import {  StyleSheet } from 'react-native';

export default StyleSheet.create({
    wrapper : {
       minHeight:'100%',
       backgroundColor:'#f1f1f1',
    },
    
});