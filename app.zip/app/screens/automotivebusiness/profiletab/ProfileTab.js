import React from 'react';
import { View, Image, Text, Linking, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native';
import styles from './styles';
import { SafeAreaView } from 'react-navigation';
import LinearGradient from 'react-native-linear-gradient';
import AsyncStorage from '@react-native-community/async-storage';
import Constants from '../../../config/constant'
import { Icon, Header, Avatar } from 'react-native-elements';
class ProfileTab extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            loading: true,
            profileImage: '',
            email: '',
            phone: '',
            address: '',
            language: '',
            website: '',
            firstName: '',
            lastName: '',
        }

        this.getProfileData();
    }


    async componentDidMount() {
        // var profile = JSON.parse(await AsyncStorage.getItem("profile"));
        // console.log('profile', profile)
        // var profileImage = profile.userdata.avatar
        // console.log('profileImage', profileImage)
    }

    async getProfileData() {
        try {
            var profile = JSON.parse(await AsyncStorage.getItem("profile"));
            //console.log('profile', profile)
            let authToken = profile.token;
            //console.log('profile', authToken)
            let response = await fetch(
                Constants.BASE_URL + 'auth/profile', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + authToken,
                    'X-Requested-With': 'XMLHttpRequest',
                },
            });
            this.setState({ loading: false })
            let responseJson = await response.json();
            console.log('fdjsioadjfuisdgj', responseJson)
            this.success(responseJson);
            return responseJson;
        } catch (error) {
            console.error(error);
            this.setState({ loading: false })
        }
    }

    async success(profiles) {
        console.log('profile', profiles)
        var image = profiles.avatar
        console.log('image', image)
        await AsyncStorage.setItem("profiles", JSON.stringify(profiles));
        this.setState({
            firstName: profiles.first_name,
            lastName: profiles.last_name,
            profileImage: profiles.business_info.profile_pic,
            email: profiles.email,
            phone: profiles.phone,
            address: profiles.business_info.address,
            language: profiles.language_id,
            website: profiles.business_info.website,
        })
    }

    goToEditBusinessProfile() {
        //console.log("gotoeditbusinessprofile******", this.props.navigation);
        this.props.navigation.navigate('EditBusinessProfile');
    }

    goBack() {
        this.props.navigation.goBack();
    }

    render() {

        let splashImg = require("../../../../assets/splash_bg.png");
        let facebook = require("../../../../assets/images/facebook.png");
        let insta = require("../../../../assets/images/Instagram.png");
        let twitter = require("../../../../assets/images/twitter.png");
        let pin = require("../../../../assets/images/edit-profile.png");
        // const {navigate} = this.props.navigation;

        return (
            <SafeAreaView style={styles.wrapper}>
                <Header
                    //leftComponent={<Button transparent onPress={this.goBack.bind(this)}><Image source={require('../../../../assets/t13.png')} style={{ width: 25, height: 25, marginBottom: 25 }} /></Button>}
                    centerComponent={{ text: 'Profile', style: { color: '#fff', marginBottom: 25, fontSize: 16 } }}
                    //rightComponent={{ icon: 'home', color: '#fff' }}
                    containerStyle={{
                        backgroundColor: '#d55459',
                        justifyContent: 'space-around',
                        height: 45,
                    }}
                />

                <ScrollView contentContainerStyle={{ minHeight: '100%' }}>
                    {this.state.loading ?
                        <ActivityIndicator
                            animating={this.state.loading}
                            color='#FF0000'
                            size="large"
                            style={styles.activityIndicator} />
                        :
                        <View>
                            <LinearGradient colors={['#d55459', '#a32227', '#96151a']} style={{ height: 180, width: '100%' }}>
                                <View style={{ marginTop: 5 }}>
                                    {/* <Image source={{ uri: this.state.profileImage }} style={{ width: 120, height: 120, borderRadius: 120 / 2, alignSelf: 'center', marginTop: 10 }}></Image>
                                    <TouchableOpacity style={{ height: 35, backgroundColor: 'black', borderRadius: 30, width: 35, position: 'absolute', padding: 5, marginTop: 100, marginLeft: 227 }} onPress={() => this.goToEditBusinessProfile()}> */}
                                    {/* <Image source={splashImg} style={{ height: 30, width: 30, borderRadius:30 }}></Image> */}
                                    {/* <Icon name='edit' size={25} type='FontAwesome' color='white' />
                                    </TouchableOpacity> */}
                                    <Avatar
                                        size={110}
                                        //onPress={this.takePicture.bind(this)}
                                        onEditPress={() => this.goToEditBusinessProfile()}
                                        overlayContainerStyle={{ backgroundColor: '#FFF' }}
                                        rounded
                                        icon={{ name: 'plus', type: 'font-awesome', color: 'gray', size: 20 }}
                                        containerStyle={{ borderColor: 'gray', borderWidth: 0, alignSelf: 'center', marginTop:10 }}
                                        source={{ uri: this.state.profileImage }}
                                        imageProps={{ resizeMode: 'cover' }}
                                        showEditButton
                                    />
                                    <Text style={{ color: '#FFFFFF', alignSelf: 'center', fontFamily: 'Roboto_Regular', marginTop: 10 }}>{this.state.firstName} {this.state.lastName}</Text>
                                </View>
                            </LinearGradient>

                            <Text style={{ marginLeft: '5%', marginRight: '5%', marginTop: 15, color: '#000000' }}>Details Info</Text>
                            <View style={{ width: '90%', marginLeft: '5%', marginRight: '5%', borderColor: '#000000', borderRadius: 1, borderWidth: 1, height: 185, marginTop: 5, backgroundColor: '#FFFFFF' }}>
                                <View style={{ height: 45, flexDirection: 'row', width: '100%', marginTop: 5 }}>
                                    <Text style={{ color: '#000000', marginLeft: 10, alignSelf: 'center', flex: 0.5 }}>Email:</Text>
                                    <Text style={{ color: '#000000', marginRight: 10, textAlign: 'right', alignSelf: 'center', flex: 1.5 }}>{this.state.email}</Text>
                                </View>
                                <View style={{ height: 45, flexDirection: 'row', width: '100%' }}>
                                    <Text style={{ color: '#000000', marginLeft: 10, alignSelf: 'center', flex: 0.5 }}>Phone:</Text>
                                    <Text style={{ color: '#000000', marginRight: 10, textAlign: 'right', alignSelf: 'center', flex: 1.5 }}>{this.state.phone}</Text>
                                </View>
                                <View style={{ height: 45, flexDirection: 'row', width: '100%' }}>
                                    <Text style={{ color: '#000000', marginLeft: 10, alignSelf: 'center', flex: 0.5 }}>Address:</Text>
                                    <Text style={{ color: '#000000', marginRight: 10, textAlign: 'right', alignSelf: 'center', flex: 1.5 }}>{this.state.address}</Text>
                                </View>
                                <View style={{ height: 45, flexDirection: 'row', width: '100%' }}>
                                    <Text style={{ color: '#000000', marginLeft: 10, alignSelf: 'center', flex: 0.5 }}>Language:</Text>
                                    <Text style={{ color: '#000000', marginRight: 10, textAlign: 'right', alignSelf: 'center', flex: 1.5 }}>{this.state.language}</Text>
                                </View>
                            </View>
                            <TouchableOpacity style={{ width: 45, height: 45, position: 'absolute', alignSelf: 'flex-end', justifyContent: 'center', marginTop: 195 }}>
                                <Image source={pin} style={{ width: 30, height: 30, alignSelf: 'center' }}></Image>
                            </TouchableOpacity>
                            <Text style={{ marginLeft: '5%', marginRight: '5%', marginTop: 15, color: '#000000' }}>Social Media Accounts</Text>
                            <View style={{ height: 45, width: '90%', marginLeft: '5%', marginRight: '5%', backgroundColor: '#FFFFFF', marginTop: 10, flexDirection: 'row' }}>
                                <Image style={{ height: 25, width: 25, marginLeft: 10, alignSelf: 'center' }} source={facebook}></Image>
                                <Image style={{ height: 25, width: 25, marginLeft: 10, alignSelf: 'center' }} source={twitter}></Image>
                                <Image style={{ height: 25, width: 25, marginLeft: 10, alignSelf: 'center' }} source={insta}></Image>
                            </View>
                            <Text style={{ marginLeft: '5%', marginRight: '5%', marginTop: 15, color: '#000000' }}>Website</Text>
                            <View style={{ height: 45, width: '90%', marginLeft: '5%', marginRight: '5%', backgroundColor: '#FFFFFF', marginTop: 10, justifyContent: 'center' }}>
                                {/* <Text style={{ marginLeft: 10 }}>{this.state.website}</Text> */}
                                <Text style={{ color: 'blue', marginLeft: 10 }} onPress={() => Linking.openURL(this.state.website)}>{this.state.website}</Text>
                            </View>
                            <TouchableOpacity onPress={() => this.props.navigation.navigate('Logout')} style={{ alignSelf: 'center', padding: 15, backgroundColor: 'green', marginBottom:20 }}>
                                <Text>LogOut</Text>
                            </TouchableOpacity>

                        </View>}
                </ScrollView>
            </SafeAreaView>
        )
    }

}

export default ProfileTab;