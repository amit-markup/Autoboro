import React, { Component } from 'react';
import {
    StyleSheet,
    Text,
    View,
    Alert,
    TouchableOpacity,
    FlatList,
    Image,
    TouchableWithoutFeedback
} from 'react-native';
import { Rating } from 'react-native-ratings';
import { Header, Left, Body, Item, Right, Button, Input, Icon, Title } from 'native-base';

export default class EventsView extends Component {

    constructor(props) {
        super(props);
        this.state = {
            dataSource: [
                { day: 1, month: 'Sep' },
                { day: 2, month: 'Jan' },
                { day: 3, month: 'Aug' },
                { day: 4, month: 'Dec' },
                { day: 5, month: 'Jul' },
                { day: 6, month: 'Oct' },
                { day: 7, month: 'Sep' },
                { day: 8, month: 'Jan' },
                { day: 9, month: 'May' },
            ],
            value: 0
        };
    }

    eventClickListener = (viewId) => {
        Alert.alert("alert", "event clicked");
    }

    goBack() {
        this.props.navigation.goBack();
    }

    render() {
        return (
            <View style={styles.container}>
                <Header style={{ backgroundColor: "#ffffff", marginBottom: 15 }}>
                    <Left>
                        <Button transparent onPress={this.goBack.bind(this)}>
                            {/* <Icon name='arrow-back'/> */}
                            <Image source={require('../../../../assets/images/next-arrow.png')} style={{ width: 21, height: 21, transform: [{ rotate: '185deg' }] }} />
                        </Button>
                    </Left>
                    <Body style={{ paddingLeft: 20 }}>
                        <Title style={{ color: 'black', fontSize: 16 }}>Services Details</Title>
                    </Body>
                </Header>

                <Header style={{ backgroundColor: 'transparent', marginLeft: 0 }} searchBar rounded noLeft noShadow>
                    <Item>
                        <Input placeholder="Search"  />
                        <Icon name="ios-search" />
                    </Item>
                    <Right style={{ backgroundColor: '#383232', maxWidth: 45, marginLeft: 10, justifyContent: 'center', marginRight: 5 }}>
                        <TouchableWithoutFeedback style={{ backgroundColor: '#383232', margin: 5 }}>
                            <Icon name="ios-funnel" style={{ fontSize: 25, padding: 6, color: 'white', backgroundColor: '#383232' }} />
                        </TouchableWithoutFeedback>
                    </Right>
                </Header>
                <FlatList enableEmptySections={true}
                    style={styles.eventList}
                    data={this.state.dataSource}
                    extraData={this.state}
                    keyExtractor={(item) => {
                        return item.id;
                    }}
                    renderItem={(item) => {
                        return (
                            <View onPress={() => this.eventClickListener("row")}>
                                <View style={styles.eventBox}>
                                    <View style={styles.eventContent}>
                                        <View style={{ flexDirection: 'row' }}>
                                            <Text style={styles.userName}>Urgently Looking Sales Manager</Text>
                                            <View style={{ paddingLeft: 40, paddingTop: 0 }}>
                                                <Text style={[styles.userNames, { fontSize: 10, paddingTop: 3 }]}>04/Aug/2018</Text>
                                            </View>
                                        </View>
                                        <Text style={styles.description}>Lorem ipsum dolor sit amet, elit consectetur ipsum dolor sit amet, elit consectetur.</Text>
                                        <View style={{ flexDirection: 'row', marginTop: 8 }}>
                                            <TouchableOpacity>
                                                <Text style={[styles.userName, { marginLeft: 5, padding: 5, backgroundColor: '#333', width: 60, borderRadius: 5, color: '#fff', paddingLeft: 18 }]}>Edit</Text>
                                            </TouchableOpacity>
                                            <TouchableOpacity>
                                                <Text style={[styles.userName, { marginLeft: 10, padding: 5, backgroundColor: '#ba4141', width: 60, borderRadius: 5, color: '#fff', paddingLeft: 13 }]}>Delete</Text>
                                            </TouchableOpacity>
                                        </View>
                                    </View>
                                </View>
                            </View>
                        )
                    }} />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#DCDCDC",
        flex: 1,
    },
    eventList: {
        marginTop: 0,
    },
    eventBox: {
        padding: 10,
        marginTop: 0,
        marginBottom: 0,
        flexDirection: 'row',
    },
    eventDate: {
        flexDirection: 'column',
    },
    eventDay: {
        width: 35,
        height: 35,
        borderRadius: 30
    },
    eventMonth: {
        fontSize: 14,
        color: "#333",
        fontWeight: "600",
    },
    eventContent: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'flex-start',
        marginLeft: 0,
        backgroundColor: '#FFFFFF',
        padding: 10,
        borderRadius: 10
    },
    description: {
        fontSize: 12,
        color: "#646464",
    },
    eventTime: {
        fontSize: 18,
        color: "#151515",
    },
    userName: {
        fontSize: 13,
        color: "#151515",
        fontWeight: 'bold'
    },
    userNames: {
        fontSize: 8,
        color: "#151515",
    },
});