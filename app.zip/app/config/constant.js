export default {
    // BASE_URL : "http://markupdesigns.in/autoborocarsolutions/api/v1/",
    BASE_URL : "http://autoboro.markupdesigns.org/api/",
};