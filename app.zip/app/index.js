import React from 'react';
import Navigator from './config/routes';
// import RoutingScreen from './config/routes';

export default () => <Navigator />;