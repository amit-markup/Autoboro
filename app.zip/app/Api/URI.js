let urls = {
	Login:"http://autoborocar.markupdesigns.org/api/v1/auth/login",
}

module.exports = urls;